import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class WordFilter {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                  new InputStreamReader(System.in));

        String[] words = Arrays.stream(reader.readLine().split(" "))
                .filter(w ->w.length()%2==0)
                .toArray(String[]::new);

        for (String word:words) {
            System.out.println(word);
        }
    }
}

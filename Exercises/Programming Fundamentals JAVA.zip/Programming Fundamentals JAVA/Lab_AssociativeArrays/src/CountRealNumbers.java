import java.util.*;

public class CountRealNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double [] numbers = Arrays.stream(scanner.nextLine().split(" "))
                .mapToDouble(Double::parseDouble).toArray();

        Map<Double,Integer> someMap = new TreeMap<>();

        for (double num:numbers) {
            if(!someMap.containsKey(num)){
                someMap.put(num,0);
            }
            someMap.put(num,someMap.get(num)+1);
        }
        for (Map.Entry<Double, Integer> kvp : someMap.entrySet()) {
            System.out.printf("%.0f -> %d%n",kvp.getKey(),kvp.getValue());
        }

    }
}

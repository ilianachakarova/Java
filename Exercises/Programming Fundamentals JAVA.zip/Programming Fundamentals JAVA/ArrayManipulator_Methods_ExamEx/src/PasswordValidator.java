import java.util.Scanner;

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String password = scanner.nextLine();

        if(!hasProperLength(password)){
            System.out.println("Password must be between 6 and 10 characters");
        }
        if(!containsDigitsAndLetters(password)){
            System.out.println("Password must consist only of letters and digits");
        }
        if(!containsAtLeast2Digits(password)){
            System.out.println("Password must have at least 2 digits");
        }

        if(hasProperLength(password) && containsAtLeast2Digits(password) && containsAtLeast2Digits(password)){
            System.out.println("Password is valid");
        }

    }

    private static boolean hasProperLength(String password){
        boolean isProperLength;
        if(password.length()<6 || password.length()>10){
            isProperLength = false;
        }else {
            isProperLength = true;
        }

        return isProperLength;
    }

    private static boolean containsDigitsAndLetters(String password){
        boolean isDigitOrLetter = false;
        for (int i = 0; i <password.length() ; i++) {

            if(Character.isLetterOrDigit(password.charAt(i))){
              isDigitOrLetter = true;
            }
            else {
                isDigitOrLetter = false;
                break;
            }
        }
        return isDigitOrLetter;
    }

    private static boolean containsAtLeast2Digits(String password){
        int count = 0;
        boolean isEnoughDigit;
        for (int i = 0; i <password.length() ; i++) {
            if(Character.isDigit(password.charAt(i))){
                count++;
            }

        }
        if(count<2){
           isEnoughDigit = false;
        }else {
            isEnoughDigit = true;
        }
        return isEnoughDigit;
    }
}

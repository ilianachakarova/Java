import java.util.Scanner;

public class StrongNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());
        int input = number;
        int currentNumber = number;
        int sum = 0;
        while ( number >0){
            int multiplication = 1;
            currentNumber = number%10;
            for(int i = currentNumber; i>0; i--){
                multiplication = i*multiplication;
            }
            sum = sum + multiplication;
            number /=10;
        }

        if(sum==input){
            System.out.println("yes");
        }else {
            System.out.println("no");
        }
    }
}

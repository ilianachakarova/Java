import java.util.Scanner;

public class PadawnEquipment {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double moneyPresent = Double.parseDouble(scanner.nextLine());
        int numStudents = Integer.parseInt(scanner.nextLine());
        double priceLightsabers = Double.parseDouble(scanner.nextLine());
        double priceRobe = Double.parseDouble(scanner.nextLine());
        double priceBelt = Double.parseDouble(scanner.nextLine());
        double freeBelts = numStudents / 6;
        freeBelts = Math.ceil(freeBelts);
        double numSabers = numStudents+0.1*numStudents;
        numSabers = Math.ceil(numSabers);
         double moneyNeeded = priceLightsabers*(numSabers)+priceBelt*(numStudents - freeBelts)+(priceRobe*numStudents);
         if(moneyPresent>=moneyNeeded){
             System.out.printf("The money is enough - it would cost %.2flv.",moneyNeeded);
         }else{
             System.out.printf("Ivan Cho will need %.2flv more.",(moneyNeeded - moneyPresent));
         }

    }
}

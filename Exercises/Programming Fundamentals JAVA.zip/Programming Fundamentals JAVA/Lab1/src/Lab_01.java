import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Lab_01 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String input = reader.readLine();
      double sum = 0;
        while(!"Start".equals(input)){
            double coinsInput = Double.parseDouble(input);
            if(coinsInput==0.1||
                    coinsInput==0.2||
                    coinsInput==0.5||
                    coinsInput==1||
                    coinsInput==2)
            {
                sum += (coinsInput);
            }
            input = reader.readLine();
        }

        String inputProduct = reader.readLine();
        while(!"End".equals(inputProduct)){
            switch (inputProduct){
                case "Nuts":
                    if(sum >= 2){
                        System.out.printf("Purchased %s", inputProduct);
                        sum -=2;
                    }else {
                        System.out.println("Sorry.");
                    }
                    break;
            }
        }
    }
}

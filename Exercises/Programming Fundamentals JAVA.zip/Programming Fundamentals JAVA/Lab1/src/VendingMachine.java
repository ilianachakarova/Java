import java.util.Scanner;

public class VendingMachine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        double sum = 0;
        while (!input.equals("Start")) {

            double coins = Double.parseDouble(input);
            if (coins == 0.1 || coins == 0.2 || coins == 0.5 || coins == 1 || coins == 2) {
                sum += coins;
            } else {
                System.out.printf("Cannot accept %.2f%n", coins);
            }

            input = scanner.nextLine();
        }

        String secondInput = scanner.nextLine();
        double moneyLeft = sum;
        double change = 0;
        while (!secondInput.equals("End")) {
            if (moneyLeft <= 0) {
                break;
            }
            if (secondInput.equals("Nuts")) {
                if (moneyLeft >= 2) {
                    System.out.println("Purchased Nuts");
                    moneyLeft -= 2;
                } else {
                    System.out.println("Sorry, not enough money");
                }
            } else if (secondInput.equals("Water")) {
                if (moneyLeft >= 0.7) {
                    System.out.println("Purchased Water");
                    moneyLeft -= 0.7;
                } else {
                    System.out.println("Sorry, not enough money");
                }
            } else if (secondInput.equals("Crisps")) {
                if (moneyLeft >= 1.5) {
                    System.out.println("Purchased Crisps");
                    moneyLeft -= 1.5;
                } else {
                    System.out.println("Sorry, not enough money");
                }
            } else if (secondInput.equals("Soda")) {
                if (moneyLeft >= 0.8) {
                    System.out.println("Purchased Soda");
                    moneyLeft -= 0.8;
                } else {
                    System.out.println("Sorry, not enough money");
                }
            } else if (secondInput.equals("Coke")) {
                if (moneyLeft >= 1) {
                    System.out.println("Purchased Coke");
                    moneyLeft -= 1;
                } else {
                    System.out.println("Sorry, not enough money");
                }
            }else {
                System.out.println("Invalid product");
            }
            secondInput = scanner.nextLine();
        }

        System.out.printf("Change: %.2f", moneyLeft);

    }
}

package Articles2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Article> articleArrayList = new ArrayList<>();

        for (int i = 0; i <n ; i++) {
            String input = scanner.nextLine();
            String[] data = input.split(", ");

            Article article = new Article(data[0],data[1],data[2]);

            articleArrayList.add(article);
        }

        String command = scanner.nextLine();
        if(command.equals("title")){
           articleArrayList = articleArrayList.stream().sorted((a1, a2)->a1.getTitle().compareTo(a2.getTitle()))
           .collect(Collectors.toList());

        }else if(command.equals("content")){
            articleArrayList = articleArrayList.stream().sorted((a1, a2)->a1.getContent().compareTo(a2.getContent()))
                    .collect(Collectors.toList());
        }else {
            articleArrayList = articleArrayList.stream().sorted((a1, a2)->a1.getAuthor().compareTo(a2.getAuthor()))
                    .collect(Collectors.toList());
        }

        System.out.println(articleArrayList.toString().replaceAll("[\\[\\],]",""));
    }
}

package VehicleCatalogue;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = "";
        List<Vehicle>vehicleList = new ArrayList<>();
        while(!"End".equals(input=scanner.nextLine())){
            String [] data = input.split(" ");
            String type = data[0];
            String model = data[1];
            String color = data[2];
           int horsepower = Integer.parseInt(data[3]);

           Vehicle vehicle = new Vehicle(type,model,color,horsepower);

           vehicleList.add(vehicle);
        }

        String criteria = scanner.nextLine();
        while (!"Close the Catalogue".equals(criteria)){
            String finalCriteria = criteria;
            vehicleList.stream()
                    .filter(v -> v.getModel().equals(finalCriteria))
                    .forEach(System.out::println);

           criteria = scanner.nextLine();
        }

        var cars = vehicleList.stream().filter(vehicle -> vehicle.getType().equals("car"))
                .collect(Collectors.toList());

        var trucks = (vehicleList.stream().filter(vehicle -> vehicle.getType().equals("truck"))
                .collect(Collectors.toList()));

        System.out.printf("Cars have average horsepower of: %.2f.%n",average(cars,"car"));
        System.out.printf("Trucks have average horsepower of: %.2f.%n",average(trucks,"truck"));


    }

    public static double average(List<Vehicle>vehicles, String type){
        if(vehicles.size()==0){
            return 0.0;
        }
        double sum = 0;
        for (Vehicle vehicle:vehicles) {
            sum += vehicle.getHorsepower();
        }
        return sum/vehicles.size();
    }
}

package Students;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                  new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());
        List<Student>studentList = new ArrayList<>();
        for (int i = 0; i <n ; i++) {
            String input = reader.readLine();
            String [] data = input.split(" ");
            String firstName = data[0];
            String lastName = data[1];
            double grade = Double.parseDouble(data[2]);

            Student student = new Student(firstName,lastName,grade);

            studentList.add(student);
        }

        studentList.stream().sorted((s1,s2)->Double.compare(s2.getGrade(),s1.getGrade()))
                .forEach(s-> System.out.println(s));

    }
}

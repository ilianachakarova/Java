package OrderByAge;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Person>personList = new ArrayList<>();
        String input = scanner.nextLine();
        while(!"End".equals(input)){
            String [] data = input.split(" ");
            String name = data[0];
            String ID = data[1];
            int age = Integer.parseInt(data[2]);

            Person person = new Person(name,ID,age);

            personList.add(person);

            input = scanner.nextLine();
        }

         personList.stream().sorted((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()))
                 .forEach(person -> System.out.println(String.format("%s with ID: %s is %d years old."
                         ,person.getName(),person.getID(),person.getAge())));


    }
}

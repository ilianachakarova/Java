import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StarEnigma {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        List<String> attackedPlanets = new ArrayList<>();
        List<String> destroyedPlanets = new ArrayList<>();

        String regex = "@(?:[^:@\\-!>,]*?)([A-Za-z]+)(?:[^:@\\-!>,]*)" +
                ":(\\d+)(?:[^:@\\-!>,]*)!([AD])!(?:[^:@\\-!>,]*)->(?:[^:@\\-!>,]*?)([\\d]+)";
        for (int i = 0; i < n; i++) {
            String input = scanner.nextLine();
            int counter = 0;
            for (int j = 0; j < input.length(); j++) {
                if (input.charAt(j) == 'S' || input.charAt(j) == 'T' || input.charAt(j) == 'A' || input.charAt(j) == 'R'
                        || input.charAt(j) == 's' || input.charAt(j) == 't' || input.charAt(j) == 'a' || input.charAt(j) == 'r') {
                    counter++;
                }
            }
            String result = "";
            for (int j = 0; j < input.length(); j++) {
                int current = (input.charAt(j) - counter);
                char currentChar = (char) current;
                result += currentChar;
            }

            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(result);

            while (matcher.find()) {
                String name = matcher.group(1);
                int population = Integer.parseInt(matcher.group(2));
                String attackType = matcher.group(3);
                int soldierCount = Integer.parseInt(matcher.group(4));
                if (attackType.equals("D")) {
                    destroyedPlanets.add(name);
                } else {
                    attackedPlanets.add(name);
                }
            }
            if(!matcher.find()){
                continue;
            }


        }

        System.out.println("Attacked planets: " + attackedPlanets.size());

            attackedPlanets.stream()
                    .sorted((e1,e2)->e1.compareTo(e2))
                    .forEach(e -> {
                System.out.println(String.format("-> %s", e));
            });

            System.out.println("Destroyed planets: " + destroyedPlanets.size());

                destroyedPlanets.stream()
                        .sorted((e1,e2)->e1.compareTo(e2))
                        .forEach(e -> {
                    System.out.println(String.format("-> %s", e));
                });

        }
    }


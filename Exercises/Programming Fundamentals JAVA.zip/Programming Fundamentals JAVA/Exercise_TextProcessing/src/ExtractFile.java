import java.util.Scanner;

public class ExtractFile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//        String regex = "^C:\\\\[A-Za-z]+\\\\[A-Za-z-]+\\\\(?<file>[A-Za-z]+).(?<ext>[a-z]+)$";
//        String input = scanner.nextLine();
//
//        Pattern pattern = Pattern.compile(regex);
//        Matcher textMatcher = pattern.matcher(input);
//
//        if(textMatcher.find()){
//            String file = textMatcher.group("file");
//            String ext = textMatcher.group("ext");
//            System.out.println("File name: "+file);
//            System.out.println("File extension: "+ext);
 //       }
        String input = scanner.nextLine();
        String[]data = input.split("\\\\");
        int length = data.length;
        String result = data[length-1];
        String file = result.substring(0,result.lastIndexOf('.'));
        String ext = result.substring(result.lastIndexOf('.')+1);
        System.out.println("File name: "+file);
        System.out.println("File extension: "+ext);

    }
}

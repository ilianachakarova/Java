import java.util.Scanner;

public class ReplaceRepeatingChars {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        String result ="";

        for (int i = 1; i <input.length() ; i++) {

            if(input.charAt(i)==input.charAt(i-1)){
                continue;
            }else {
                result+=input.charAt(i);
            }
        }
        System.out.println(input.charAt(0)+result);
    }
}

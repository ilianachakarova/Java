import java.util.Scanner;

public class CaesarCipher {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        String output ="";

        for (int i = 0; i <input.length() ; i++) {
            char current = (char) (input.charAt(i)+3);
            output+=current;
        }

        System.out.println(output);
    }
}

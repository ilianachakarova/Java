import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractEmails {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String regex = "(?<= )([a-z0-9][a-z-\\._0-9]+)@([a-z][a-z-]+)(\\.([a-z]+))+";

        String text = scanner.nextLine();

        Pattern pattern = Pattern.compile(regex);
        Matcher mailMatcher = pattern.matcher(text);

        while (mailMatcher.find()){
            System.out.println(mailMatcher.group());
        }

    }
}

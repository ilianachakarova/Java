import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SoftUniBarIncome {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Double> income = new ArrayList<>();
        String input ="";
        //String regex = "%(?<name>[A-Z][a-z]+)%[A-Za-z0-9]*<(?<product>[A-Z][a-z]+)>" +
            //    "[A-Za-z0-9]*\\|(?<quantity>[\\d]+)\\|[A-Za-z]*(?<price>([\\d\\.])+)\\$";
        String regex ="%([A-Z][a-z]+)%(?:[^%$.|]*)<(.*?)>(?:[^%$.|]*)\\|(\\d+)\\|(?:[^%$.|]*?)([\\d.\\d+]+)\\$";
        while(!"end of shift".equals(input= scanner.nextLine())){
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(input);

            if(matcher.find()){
                String name = matcher.group(1);
                String product = matcher.group(2);
                double quantity = Double.parseDouble(matcher.group(3));
                double price = Double.parseDouble(matcher.group(4));

                double profit = quantity*price;
                income.add(profit);

                System.out.println(String.format("%s: %s - %.2f",name,product,profit));
            }
        }
        double total =0;
        for (int i = 0; i <income.size() ; i++) {
            total+=income.get(i);
        }
        System.out.printf("Total income: %.2f",total);
    }
}

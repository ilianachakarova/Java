import java.util.Scanner;

public class ValidUsernames {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        String [] usernames = input.split(", ");


        for (int i = 0; i <usernames.length ; i++) {
            String result = "";
            if(usernames[i].length()>=3 && usernames[i].length()<=16){
                for (int j = 0; j <usernames[i].length() ; j++) {
                    if(Character.isLetterOrDigit(usernames[i].charAt(j))
                            ||(usernames[i].charAt(j) == '-' ||(usernames[i].charAt(j)=='_' ))){
                       result += usernames[i].charAt(j);
                    }
                }
            }
            if(result.length()==usernames[i].length()) {
                System.out.println(result);
            }
        }


    }
}

import java.util.*;
import java.util.stream.Collectors;

public class Race {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String participants = scanner.nextLine();
       List<String> listParticipants = Arrays.stream(participants.split(", ")).collect(Collectors.toList());
        LinkedHashMap<String,Integer>result = new LinkedHashMap<>();

        String input = "";
        while (!"end of race".equals(input=scanner.nextLine())) {
            String name ="";
            int distance =0;
            for (int i = 0; i <input.length() ; i++) {
                if(Character.isLetter(input.charAt(i))){
                    name+=input.charAt(i);
                }else if(Character.isDigit(input.charAt(i))) {
                    distance += Integer.parseInt(String.valueOf(input.charAt(i)));

                }
            }

            if(listParticipants.contains(name)){
                if(!result.containsKey(name)){
                    result.put(name,distance);
                }else {
                    result.put(name,result.get(name)+distance);
                }
            }

        }
        List<String>names = new LinkedList<>();
       result.entrySet().stream()
               .sorted((e1,e2)->Integer.compare(e2.getValue(),e1.getValue()))
               .limit(3).forEach(p->names.add(p.getKey()));
        System.out.println("1st place: "+ names.get(0));
        System.out.println("2nd place: "+ names.get(1));
        System.out.println("3rd place: "+ names.get(2));
    }
}

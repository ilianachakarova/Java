import java.util.Scanner;

public class CharacterMultiplier {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//        String [] input = scanner.nextLine().split("\\s+");
//        String s1 = input[0];
//        String s2 = input[1];
//        System.out.println(doMagic(s1,s2));
        String input = scanner.nextLine();
        String firstWord = input.substring(0,input.indexOf(' '));
        String secondWord = input.substring(input.lastIndexOf(' ')+1);

        System.out.println(doMagic(firstWord,secondWord));

    }
    public static int doMagic(String s1, String s2){
        int sum =0;
        int min = Math.min(s1.length(),s2.length());
        int max = Math.max(s1.length(),s2.length());
        String longerWord = s1.length()<s2.length()?s2:s1;

        for (int i = 0; i <min ; i++) {
            sum+= s1.charAt(i)*s2.charAt(i);
        }
        for (int i = min; i <max ; i++) {
            sum+=longerWord.charAt(i);
        }
//        if(s1.length()==s2.length()){
//            for (int i = 0; i <s1.length() ; i++) {
//                sum+=s1.charAt(i)*s2.charAt(i);
//            }
//        }else {
//            if(s1.length()>s2.length()){
//                for (int i = 0; i <s2.length() ; i++) {
//                    sum+=s1.charAt(i)*s2.charAt(i);
//                }
//                String remainder = s1.substring(s1.length(),s2.length());
//                for (int i = 0; i <remainder.length() ; i++) {
//                    sum+=remainder.charAt(i);
//                }
//            }else if(s1.length()<s2.length()){
//                for (int i = 0; i <s1.length() ; i++) {
//                    sum+=s1.charAt(i)*s2.charAt(i);
//                }
//                String remainder = s2.substring(s1.length(),s2.length());
//                for (int i = 0; i <remainder.length() ; i++) {
//                    sum+=remainder.charAt(i);
//                }
//            }
//        }
//        return sum;
        return sum;
    }
}

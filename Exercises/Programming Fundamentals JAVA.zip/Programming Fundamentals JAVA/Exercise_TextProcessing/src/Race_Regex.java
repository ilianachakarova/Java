import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Race_Regex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String>participants = Arrays.stream(scanner.nextLine().split(", "))
                .collect(Collectors.toList());

        LinkedHashMap<String, Integer> results = new LinkedHashMap<>();

        String input = "";
        while (!"end of race".equals(input=scanner.nextLine())){
            String name ="";
            int distance =0;


            String regex ="[A-Za-z]+";
            Pattern pattern = Pattern.compile(regex);
            Matcher nameMatcher = pattern.matcher(input);

            for (int i = 0; i <input.length() ; i++) {
                if(nameMatcher.find()){
                    name+=input.charAt(i);
                }
            }


            String regex2= "[\\d]+";
            Pattern pattern2 = Pattern.compile(regex);
            Matcher digitMatcher = pattern.matcher(input);
            for (int i = 0; i <input.length() ; i++) {
                if(digitMatcher.find()){
                    distance+=Integer.parseInt(String.valueOf(input.charAt(i)));
                }
            }

            if(!results.containsKey(name)) {
                while (participants.contains(name)) {
                    results.put(name, distance);
                }
            }else {
                results.put(name,results.get(name)+distance);
            }

        }

        List<String>names = new ArrayList<>();

        results.entrySet().stream()
                .sorted((e1,e2)->Integer.compare(e2.getValue(),e1.getValue()))
                .limit(3).forEach(e->names.add(e.getKey()));

        System.out.println(String.format("1st place: %s",names.get(0)));
        System.out.println(String.format("2nd place: %s",names.get(1)));
        System.out.println(String.format("3rd place: %s",names.get(2)));
    }
}

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Furniture {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


      //  String regex = ">>(?<item>[A-Z][A-Za-z]+)<<(?<price>[\\d]+\\.*\\d+)!(?<qty>[\\d])";
        String regex = "^>>(?<item>[A-Za-z\\s]+)<<(?<price>\\d+(.\\d+)?)!(?<quantity>\\d+)";
       // String regex = "\"^>+([?<furniture>A-Z{0,}a-z]+)+<<(?<price>\\\\d+\\\\.?\\\\d+)+!([?<quantity>\\\\d+]+)\\\\b\"";



        List<String>boughtItems = new ArrayList<>();
        String  input = scanner.nextLine();
        double sum = 0;
        while (!"Purchase".equals(input)){
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(input);

            while (matcher.find()){
                boughtItems.add(matcher.group("item"));
                sum+= Double.parseDouble(matcher.group("price"))*Integer.parseInt(matcher.group("quantity"));
            }
            input = scanner.nextLine();
        }
        System.out.println("Bought furniture:");
        System.out.println(String.join("\n",boughtItems));
        System.out.println(String.format("Total money spend: %.2f",sum));
    }
}

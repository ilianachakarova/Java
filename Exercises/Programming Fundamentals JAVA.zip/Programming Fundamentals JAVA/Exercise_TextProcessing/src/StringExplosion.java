import java.util.Scanner;

public class StringExplosion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        String res = "";

        for (int i = 0; i < input.length(); i++) {
            char symbol = input.charAt(i);
            if (symbol == '>') {
                res += symbol;
                i++; // goes to the next index
                int power = input.charAt(i) - '0';
                power--;

                while (power > 0 && i < input.length() - 1) {
                    i++;
                    symbol = input.charAt(i);
                    if (symbol == '>') {
                        res += symbol;
                        i++;
                        power += input.charAt(i) - '0';
                        //continue;
                    }
                    power--;
                }
            } else {
                res += symbol;

            }
        }

        System.out.println(res);
    }
}

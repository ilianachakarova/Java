import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class NetherRealms {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        List<String>names = Arrays.stream(input.split(",\\s*")).collect(Collectors.toList());

        String regex ="[A-Za-z0-9-+*\\.\\\\]+";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        String name = "";
        int health = 0;
        int damage = 0;
        while (matcher.find()){
            for (int i = 0; i <matcher.group().length() ; i++) {
                if(Character.isLetter(matcher.group().charAt(i))){
                    name+=matcher.group().charAt(i);
                    health+=(int)matcher.group().charAt(i);
                }else if(!Character.isLetter(matcher.group().charAt(i))){

                }
            }
        }


    }
}

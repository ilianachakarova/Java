import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SeizeTheFire {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> input = Arrays.stream(scanner.nextLine().split("#"))
                .collect(Collectors.toList());
        int water = Integer.parseInt(scanner.nextLine());
        double totalEffort = 0;
        double totalFire = 0;
        System.out.println("Cells:");
        for (int i = 0; i <input.size() ; i++) {
            String part = input.get(i);
            String [] commands = part.split(" = ");
            int valueOfTheCell =Integer.parseInt(commands[1]);
            switch (commands[0]){
                case"High":
                    if(valueOfTheCell>=81&&valueOfTheCell<=125){
                        if(water>=valueOfTheCell) {
                            water -= valueOfTheCell;
                            totalEffort += 0.25 * valueOfTheCell;
                            totalFire += valueOfTheCell;
                            System.out.println(" - "+valueOfTheCell);
                        }else {
                            break;
                        }
                    }
                    break;
                case"Medium":
                    if(valueOfTheCell>=51&&valueOfTheCell<=80){
                        if(water>=valueOfTheCell) {
                            water -= valueOfTheCell;
                            totalEffort += 0.25 * valueOfTheCell;
                            totalFire += valueOfTheCell;
                            System.out.println(" - "+valueOfTheCell);
                        }else {
                            break;
                        }
                }
                    break;
                case "Low":
                    if(valueOfTheCell>=1&&valueOfTheCell<=50){
                        if(water>=valueOfTheCell) {
                            water -= valueOfTheCell;
                            totalEffort += 0.25 * valueOfTheCell;
                            totalFire += valueOfTheCell;
                            System.out.println(" - "+valueOfTheCell);
                        }else {
                            break;
                        }
                    }
                    break;
            }
        }
        System.out.printf("Effort: %.2f%n",totalEffort);
        System.out.printf("Total Fire: %.0f",totalFire);
    }
}

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class TheFinalQuest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> input = Arrays.stream(scanner.nextLine().split(" "))
                .collect(Collectors.toList());

        String command = scanner.nextLine();

        while (!"Stop".equals(command)){
          String [] execute = command.split(" ");
          String action = execute[0];
          switch (action){
              case"Delete":
                  if(Integer.parseInt(execute[1])+1>=0&&Integer.parseInt(execute[1])+1<input.size()){
                      input.remove(input.get(Integer.parseInt(execute[1])+1));
                  }
                  break;
              case "Swap":
                  if(input.contains(execute[1])&&input.contains(execute[2])){
                      String swapWord = execute[2];
                      int two = input.indexOf(execute[2]);
                      int one = input.indexOf(execute[1]);
                      input.set(two,execute[1]);
                      input.set(one,execute[2]);

                  }
                  break;
              case"Put":
                  if(Integer.parseInt(execute[2])-1>=0&&Integer.parseInt(execute[2])-1<=input.size()){
                      input.add((Integer.parseInt(execute[2])-1),execute[1]);
                  }
                  break;
              case"Sort":
                  List<String>reverse = new ArrayList<>();
                  for (int i = input.size()-1; i>=0 ; i--) {
                      reverse.add(input.get(i));
                  }
                  input = reverse;
                  break;
                  case"Replace":
                      if(input.contains(execute[2])){
                          int index = input.indexOf(execute[2]);
                          input.set(index,execute[1]);
                      }
                      break;

          }
            command = scanner.nextLine();
        }

        System.out.println(input.toString().replaceAll("[\\[\\],]",""));
    }
}

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class DungeonestDark {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        List<String> input = Arrays.stream(scanner.nextLine().split("\\|")).collect(Collectors.toList());
        int currentHealth = 100;
        int currentCoins = 0;
        int counter =0;
        for (int i = 0; i <input.size() ; i++) {
            counter++;
            String part = input.get(i);
            String[] command = part.split(" ");
            if(command[0].equals("potion")){
                int healNumber = Integer.parseInt(command[1]);
                if(Integer.parseInt(command[1])<0){
                    return;
                }
                if(currentHealth+healNumber<=100) {
                    currentHealth+=healNumber;
                    System.out.printf("You healed for %d hp.%n",healNumber);
                    System.out.printf("Current health: %d hp.%n",currentHealth);
                }else {

                    System.out.printf("You healed for %d hp.%n",100 - currentHealth);
                    System.out.printf("Current health: %d hp.%n",100);
                    currentHealth =100;
                }
            }else if(command[0].equals("chest")){
                int coinsFound = Integer.parseInt(command[1]);
                if(Integer.parseInt(command[1])<0){
                    return;
                }
                System.out.println(String.format("You found %d coins.",coinsFound));
                currentCoins += coinsFound;
            }else{
                int attackNumber = Integer.parseInt(command[1]);
                if(Integer.parseInt(command[1])<0){
                    return;
                }
                currentHealth = currentHealth-attackNumber;
                if(currentHealth>0){
                    System.out.printf("You slayed %s.%n", command[0]);
                }else {
                    System.out.printf("You died! Killed by %s.%n",command[0]);
                    break;
                }
            }

        }

        if(counter == input.size()){
            System.out.println("You've made it!");
            System.out.println(String.format("Coins: %d",currentCoins));
            System.out.println(String.format("Health: %d",currentHealth));
        }else {
            System.out.println(String.format("Best room: %d",counter));
        }
    }
}

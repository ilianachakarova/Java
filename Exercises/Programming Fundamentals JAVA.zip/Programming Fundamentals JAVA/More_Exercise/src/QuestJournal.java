import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class QuestJournal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> input = Arrays.stream(scanner.nextLine().split(", "))
                .collect(Collectors.toList());

        String commands = scanner.nextLine();
        while (!commands.equals("Retire!")){
            String [] parts = commands.split(" - ");

            switch (parts[0]){
                case "Start":
                    if(!input.contains(parts[1])){
                        input.add(parts[1]);
                    }
                    break;
                case "Complete":
                    if(input.contains(parts[1])){
                        input.remove(parts[1]);
                    }
                    break;
                case "Side Quest":
                    String[] sideQuest = parts[1].split(":");
                    if(input.contains(sideQuest[0])&&(!input.contains(sideQuest[1]))){
                       int index = input.indexOf(sideQuest[0]);
                       input.add(index+1,sideQuest[1]);
                    }
                    break;
                case "Renew":
                    if(input.contains(parts[1])){
                        input.remove(parts[1]);
                        input.add(parts[1]);
                    }
                    break;
            }
            commands = scanner.nextLine();
        }

        System.out.println(input.toString().replaceAll("[\\[\\]]", ""));

    }
}

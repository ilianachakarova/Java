import java.util.Scanner;

public class PartyProfit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int companions = Integer.parseInt(scanner.nextLine());
        int days = Integer.parseInt(scanner.nextLine());
      double totalCoins = days*50;


            for (int i = 1; i <=days ; i++) {
                if(i %10==0){
                    companions-=2;
                }
                if(i%15==0){
                    companions+=5;
                }
                totalCoins -= companions*2;
                if(i%3==0){
                    totalCoins = totalCoins - 3*companions;
                }
                if(i%5==0){
                    totalCoins +=20*companions;
                    if(i%3==0){
                        totalCoins -= 2*companions;
                    }
                }
            }

            int profitPerCompanion = (int)totalCoins/companions;

            System.out.printf("%d companions received %d coins each.", companions, profitPerCompanion);

    }
}

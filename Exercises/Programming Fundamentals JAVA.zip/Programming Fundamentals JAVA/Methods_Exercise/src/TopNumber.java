import java.util.Scanner;

public class TopNumber {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        checkProperties(n);

        }
        static void checkProperties(int n){

            for (int i = 1; i <=n ; i++) {
               if(isDivisible(i)==true && hasOdds(i)==true){
                   System.out.println(i);
               }

            }
        }

        static boolean isDivisible(int i){
        int sum = 0;
        boolean divisible = false;
           while (i>0){
               int digit = i%10;
               sum +=digit;
               i /=10;

           }
           if(sum%8==0){
               divisible = true;
           }
           return divisible;
        }

        static  boolean hasOdds(int i){
        boolean containsOdds = false;
            while (i>0){
                int digit = i%10;
                if(digit%2 != 0){
                    containsOdds = true;
                }
                i /=10;

            }
            return containsOdds;
        }

        }





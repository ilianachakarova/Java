import java.util.Scanner;

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String password = scanner.nextLine();

        checkLength(password);
        checkSpecialCharacter(password);
        checkDigits(password);

        if(checkSpecialCharacter(password) == false && checkDigits(password) == true &&checkLength(password)==true){
            System.out.println("Password is valid");
        }

    }


    static boolean checkSpecialCharacter(String password) {
        boolean hasSpecialChars = false;
        for (int i = 0; i < password.length(); i++) {
            if (password.charAt(i) >= 32 && password.charAt(i) <= 47) {
                hasSpecialChars = true;
            }
        }
        if(hasSpecialChars=true){
            System.out.println("Password must consist only of letters and digits");
        }
        return hasSpecialChars;
    }

    static boolean checkLength(String password ){
        boolean hasGoodLength = true;
        if (password.length() < 6 || password.length() > 10) {
            System.out.println("Password must be between 6 and 10 characters");
            hasGoodLength = false;
        }
        return hasGoodLength;
    }

    static boolean checkDigits(String password){
        boolean hasDigits = true;
        int count = 0;
        for (int i = 0; i <password.length() ; i++) {
            if(password.charAt(i)>=48 && password.charAt(i)<=57){
                count++;
            }
        }
        if(count<2){
            System.out.println("Password must have at least 2 digits");
            hasDigits = false;
        }
        return hasDigits;
    }
}

import java.util.Scanner;

public class FactorialDivision {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());
        double result = calculateFactorial(a)/calculateFactorial(b);
        System.out.printf("%.2f", result);

    }

    static double calculateFactorial(int a){
        int factorialA= 1;

        if(a>0) {
            for (int i = a; i > 0; i--) {
                factorialA *= i;
            }
        }else if(a<0){
            for (int i = a; i < 0; i++) {
                factorialA *= i;
            }
        }else {
            factorialA = 0;
        }

        return factorialA;
    }

}

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TakeSkipRope {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      String input = scanner.nextLine();

        List<Character> digits = new ArrayList<>();
        List<Character> nonDigit = new ArrayList<>();

        for (int i = 0; i <input.length() ; i++) {
           if(Character.isDigit(input.charAt(i))){
               digits.add(input.charAt(i));
           }else {
               nonDigit.add(input.charAt(i));
           }
        }
        List<Character>takeList = new ArrayList<>();
        List<Character>skipList = new ArrayList<>();

        for (int i = 0; i <digits.size() ; i+=2) {
           takeList.add(digits.get(i));
           skipList.add(digits.get(i+1));
        }

        List<Character>result = new ArrayList<>();
        for (int i = 0; i <takeList.size() ; i++) {
            if(takeList.get(i)!=0){
                for (int j = 0; j <takeList.get(i) ; j++) {
                    result.add(nonDigit.get(j));

                }

            }
        }
        System.out.println(digits);
        System.out.println(nonDigit);
        System.out.println(takeList);
        System.out.println(skipList);
    }
}

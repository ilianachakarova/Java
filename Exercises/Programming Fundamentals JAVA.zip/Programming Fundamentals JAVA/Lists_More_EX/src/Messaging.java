import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Messaging {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            List<String> numbers = Arrays.stream(scanner.nextLine().split(" "))
                    .collect(Collectors.toList());



            List<String>sentance = Arrays.stream((scanner.nextLine()).split(""))
                    .collect(Collectors.toList());

            for (int i = 0; i <numbers.size() ; i++) {
                String sum = numbers.get(i);
                int index = 0;
                for (int j = 0; j <sum.length() ; j++) {
                    index += Integer.parseInt(String.valueOf(sum.charAt(j)));

                }
                if(index>=sentance.size()){
                    index = index-(sentance.size());
                    System.out.print(sentance.get(index));
                    sentance.remove(index);

                }else {
                    System.out.print(sentance.get(index));
                    sentance.remove(index);
                }

            }

        }

}

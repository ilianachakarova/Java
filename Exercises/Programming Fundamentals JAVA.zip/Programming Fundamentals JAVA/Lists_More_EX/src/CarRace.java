import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class CarRace {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer>numbers = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt).collect(Collectors.toList());

        int finishLineIndex = numbers.size()/2;

        double sumLeft = 0;
        double sumRight = 0;

        for (int i = 0; i <finishLineIndex ; i++) {
          sumLeft+=numbers.get(i);
          if(numbers.get(i)==0){
              sumLeft -=0.2*sumLeft;
          }
        }

        for (int i = numbers.size()-1; i >=finishLineIndex+1 ; i--) {
            sumRight += numbers.get(i);
            if(numbers.get(i)==0){
                sumRight -=0.2*sumRight;
            }
        }

        if(sumLeft<sumRight){
            System.out.printf("The winner is left with total time: %.1f",sumLeft);
        }else {
            System.out.printf("The winner is right with total time: %.1f",sumRight);
        }

    }
}

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SantasList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String>nameList = Arrays.stream(scanner.nextLine().split("&"))
                .collect(Collectors.toList());

        String input = scanner.nextLine();

        while(!"Finished!".equals(input)){
            String []command = input.split(" ");
            switch (command[0]){
                case "Bad":
                    if(nameList.contains(command[1])){
                        break;
                    }else {
                        nameList.add(0,command[1]);
                    }
                    break;
                case "Good":
                    if(nameList.contains(command[1])){
                        nameList.remove(command[1]);
                    }
                    break;
                case "Rename":
                    if(nameList.contains(command[1])){
                       int replaceIndex= nameList.indexOf(command[1]);
                       nameList.remove(replaceIndex);
                       nameList.add(replaceIndex,command[2]);
                    }
                    break;
                case "Rearrange":
                    if(nameList.contains(command[1])){
                        nameList.remove(command[1]);
                        nameList.add(command[1]);
                    }
                    break;
            }
            input = scanner.nextLine();
        }

        System.out.println(nameList.toString().replaceAll("[\\[\\]]",""));

    }
}

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class PresentDelivery {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> list = Arrays.stream(scanner.nextLine().split("@"))
                .map(Integer::parseInt).collect(Collectors.toList());

        String input = scanner.nextLine();
        int currentPosition = 0;
        while (!"Merry Xmas!".equals(input)) {
            String[] command = input.split(" ");
            int indexToChange = 0;
            int jumpLength = Integer.parseInt(command[1]);
            if(currentPosition + jumpLength > list.size()) {
                while (currentPosition + jumpLength > list.size()) {
                    currentPosition = (currentPosition + jumpLength)%jumpLength;
                    indexToChange = (list.get(currentPosition));
                    list.set(currentPosition, indexToChange - 2);

                }

            }else if(currentPosition+jumpLength<=list.size()) {
                currentPosition += jumpLength;
               indexToChange = (list.get(currentPosition));
                list.set(currentPosition, indexToChange - 2);
            }
            if(list.get(currentPosition)==0){
                System.out.printf("House %d will have a Merry Christmas.%n",currentPosition);
                break;
            }


            input = scanner.nextLine();
        }




        System.out.printf("Santa's last position was %d.%n", currentPosition);
        if (listContainsZerosOnly(list)) {
            System.out.println("Mission was successful.%n");
        } else {
            getHousesFailed(list);
        }

    }

    private static void getHousesFailed(List<Integer> list) {
        int counter = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) != 0) {
                counter++;
            }
        }
        System.out.printf("Santa has failed %d houses.", counter);
    }

    private static boolean listContainsZerosOnly(List<Integer> list) {
        int counter = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == 0) {
                counter++;
            }
            if (list.size() == counter) {
                return true;
            }
        }
        return false;
    }
}
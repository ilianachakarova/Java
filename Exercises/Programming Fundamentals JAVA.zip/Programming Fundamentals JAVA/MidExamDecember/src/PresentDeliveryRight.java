import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class PresentDeliveryRight {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer>houses = Arrays.stream(scanner.nextLine().split("@"))
                .map(Integer::parseInt).collect(Collectors.toList());

        String input = "";

        int currentPosition = 0;
        int lastPositionIndex = 0;

        while (!"Merry Xmas!".equals(input=scanner.nextLine())){
            String [] command = input.split(" ");
            int jumpLength = Integer.parseInt(command[1]);

            if(command[0].equals("Jump")){
                for (int i = 0; i <houses.size() ; i++) {
                    if(jumpLength+currentPosition>=0 && jumpLength+currentPosition<houses.size()){
                        currentPosition += jumpLength;
                    }else {
                        currentPosition = (currentPosition+jumpLength)% houses.size();
                    }

                    lastPositionIndex=currentPosition;

                    if(houses.get(currentPosition)==0){
                        System.out.printf("House %d will have a Merry Christmas.%n",currentPosition);
                        break;
                    }else {
                        int indexToChange = houses.get(currentPosition);
                        houses.set(currentPosition,indexToChange-2);
                        break;
                    }


                }
            }
        }

        int failedHouses = 0;

        for (int i = 0; i <houses.size() ; i++) {
            if(houses.get(i)!=0){
                failedHouses++;
            }

        }

        System.out.printf("Santa's last position was %d.%n",lastPositionIndex);

        if(failedHouses==0){
            System.out.println("Mission was successful.");
        }else {
            System.out.printf("Santa has failed %d houses.",failedHouses);
        }

    }
}

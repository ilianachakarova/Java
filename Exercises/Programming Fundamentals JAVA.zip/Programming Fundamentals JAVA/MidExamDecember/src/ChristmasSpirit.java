import java.util.Scanner;

public class ChristmasSpirit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int quantity = Integer.parseInt(scanner.nextLine());
        int days = Integer.parseInt(scanner.nextLine());

        int ornamentSet = 2;
        int treeSkirt = 5;
        int treeGerlands = 3;
        int treeLights = 15;

        int christmasSpirit = 0;
        int totalCost = 0;
if((days>=0&&days<=100)&&(quantity>=0&&quantity<=100)){
        for (int i = 1; i <=days ; i++) {
            if(i%11==0){
                quantity+=2;
            }
            if(i%2==0){
                totalCost+=quantity*ornamentSet;
                christmasSpirit +=5;
            }
            if(i%3==0){
                totalCost += treeSkirt*quantity;
                totalCost+= quantity*treeGerlands;
                christmasSpirit+=13;
            }
            if(i%5==0){
                totalCost += quantity*treeLights;
                christmasSpirit+=17;
                if(i%3==0){
                    christmasSpirit+=30;
                }
            }
            if(i%10 == 0){
                christmasSpirit-=20;
                totalCost+=(treeGerlands+treeSkirt+treeLights);
            }
        }
        if ((days)%10==0){
            christmasSpirit-=30;
        }

        if(days==0){
            christmasSpirit=0;
            totalCost=0;
        }

        System.out.println("Total cost: "+totalCost);
        System.out.println("Total spirit: "+christmasSpirit);

    }
    }

}

package MoreExercise;

import java.util.Scanner;

public class GamingStore {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String gameName = "";
        double gamePrice = 0;
        double moneySpent =0;
        float currentBalance = Float.parseFloat(scanner.nextLine());
        String input = scanner.nextLine();

        while(!"Game Time".equals(input)){

            switch (input){

                case "OutFall 4":
                    gamePrice = 39.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if(currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                        System.out.println("Not enough money");
                        return;
                    }
                    break;
                case "CS: OG":
                    gamePrice = 15.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if (currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                        System.out.println("Not enough money");
                        return;
                    }
                    break;
                case "Zplinter Zell":
                    gamePrice = 19.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if (currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                        System.out.println("Not enough money");
                        return;
                    }
                    break;
                case "Honored 2":
                    gamePrice = 59.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if(currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                        System.out.println("Not enough money");
                        return;
                    }
                    break;
                case "RoverWatch":
                    gamePrice = 29.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if(currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                    System.out.println("Not enough money");
                    return;
                }
                    break;
                case "RoverWatch Origins Edition":
                    gamePrice = 39.99;
                    if(currentBalance<0){
                        System.out.println("Too expensive");
                    }else if (currentBalance>0){
                        currentBalance -=gamePrice;
                        moneySpent +=gamePrice;
                        System.out.println("Bought "+ input);
                    }else{
                        System.out.println("Not enough money");
                        return;
                    }
                    break;
                    default:
                        System.out.println("Not Found");
                        break;
            }

           input = scanner.nextLine();
        }
        System.out.printf("Total spent: $%.2f. Remaining: $%.2f",moneySpent,currentBalance);
    }
}
//if(currentBalance<=0){
//                System.out.println("Out of money!");
//                return;
//            }
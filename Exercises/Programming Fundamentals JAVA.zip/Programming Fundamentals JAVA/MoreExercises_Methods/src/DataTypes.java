import java.util.Scanner;

public class DataTypes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if(input.equals("int")){
            multiplyBy2(Integer.parseInt(scanner.nextLine()));
        }else if(input.equals("real")){
            multiplyByFloat(Double.parseDouble(scanner.nextLine()));
        }else {
            addDollarSign(scanner.nextLine());
        }


    }

    static void multiplyBy2(int input){
        int result = ((input))*2;
        System.out.println(result);
    }

    static void multiplyByFloat(double input){
        double result = (input)*1.5;
        System.out.printf("%.2f", result);
    }

    static void addDollarSign (String input){
        String result = "$"+input+"$";
        System.out.println(result);
    }
}

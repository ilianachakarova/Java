package MoreExcercise;

import java.util.Scanner;

public class DecryptingMessages {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int key = Integer.parseInt(scanner.nextLine());
        int n = Integer.parseInt(scanner.nextLine());
        char letter = ' ';
        for (int i = 0; i <n ; i++) {
          letter = scanner.nextLine().charAt(0);
            letter = (char) (key+letter);

          System.out.print(letter);
        }

    }
}

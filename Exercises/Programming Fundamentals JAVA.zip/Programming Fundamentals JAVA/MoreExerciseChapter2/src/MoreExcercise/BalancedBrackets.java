package MoreExcercise;

import java.util.Scanner;

public class BalancedBrackets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        String input = " ";
        int countOpening =0;
        int countClosing=0;
        for (int i = 0; i <n ; i++) {
            input = scanner.nextLine();
            if(countOpening - countClosing>=2 || countClosing-countOpening>=2){
                System.out.println("UNBALANCED");
                return;
            }
            if((int)input.charAt(0)==40){
                countOpening++;
            }else if((int)input.charAt(0)== 41){
                countClosing++;
            }

        }
        if(countOpening==countClosing){
            System.out.println("BALANCED");
        }else{
            System.out.println("UNBALANCED");
        }
    }
}

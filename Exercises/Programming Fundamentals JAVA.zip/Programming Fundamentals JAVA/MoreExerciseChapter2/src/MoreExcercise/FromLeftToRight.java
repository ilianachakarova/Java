package MoreExcercise;

import java.util.Scanner;

public class FromLeftToRight {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int N = Integer.parseInt(scanner.nextLine());


        for (int i = 1; i <= N; i++) {
        double num1 = Double.parseDouble(scanner.next());
        double num2 = Double.parseDouble(scanner.next());
            int sumLeft = 0;
            int sumRight = 0;
        if(num1>num2){
             double number1 = Math.abs(num1);
            while(number1>0){

                sumLeft += number1 % 10;
                number1 =(long)number1 / 10;
            }
            System.out.println(Math.abs(sumLeft));
        }else {
            double number2  = Math.abs(num2);
            while(number2>0){

                 sumRight +=number2%10;;
                number2 =(long) number2/10;
            }
            System.out.println(Math.abs(sumRight));
        }

        }

    }
}

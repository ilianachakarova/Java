package Excercise;

import java.util.Scanner;

public class EuqalSums {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String [] input = scanner.nextLine().split(" ");
        int[] numbers = new int [input.length];
        boolean isEqual = false;
        for (int i = 0; i <input.length ; i++) {
            numbers[i]=Integer.parseInt(input[i]);

        }

        for (int i = 0; i <numbers.length ; i++) {
            int leftSum = 0;
            for (int j = 0; j <i ; j++) {
                leftSum += numbers[j];
            }


            int rightSum = 0;
            for (int k = i+1; k <numbers.length ; k++) {
                rightSum +=numbers[k];
            }

            if(leftSum == rightSum){
                System.out.println(i);
                isEqual = true;
            }
        }
        if(isEqual==false) {
            System.out.println("no");
        }
    }
}

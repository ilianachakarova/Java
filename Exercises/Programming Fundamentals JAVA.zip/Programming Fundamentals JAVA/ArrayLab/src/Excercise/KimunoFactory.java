package Excercise;

import java.util.Arrays;
import java.util.Scanner;

public class KimunoFactory {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = Integer.parseInt(scanner.nextLine());


        String input = scanner.nextLine();
        int bestSequenceIndex = Integer.MAX_VALUE;
        int bestSequenceSum = 0;
        int bestSequenceOutput = 0;
        int bestSequenceOutputMAx =0;
        String sequenceOutput = " ";
        while(!(input = scanner.nextLine()).equals("Clone Them")){
            ++bestSequenceOutput;
            String [] data = Arrays.stream(scanner.nextLine().split("!+"))
                    .filter(e -> !e.equals("")).toArray(String[]::new);

            int [] sequenceDNA = new int [size];
            int index = 0;
            for (int i = 0; i <data.length ; i++) {
                sequenceDNA[index++] = Integer.parseInt(data[i]);
            }

            int maxCount = 0;
            int sequenceIndex = 0;
            for (int i = 0; i <sequenceDNA.length ; i++) {
                int currentCount = 0;
                for (int j = i; j <sequenceDNA.length ; j++) {
                    if(sequenceDNA[i]==sequenceDNA[j]){
                        currentCount++;
                        if(currentCount>maxCount){
                            maxCount = currentCount;
                        sequenceIndex = i;
                        }
                    }
                    else {
                        break;
                    }

                    }
            }

            int sequenceSum = 0;
            for (int i = 0; i <sequenceDNA.length ; i++) {
                sequenceSum += sequenceDNA[i];
            }

            if(sequenceIndex<bestSequenceIndex || sequenceSum>bestSequenceSum ){
                sequenceOutput = " ";
                bestSequenceIndex = sequenceIndex;
                bestSequenceSum = sequenceSum;
                bestSequenceOutputMAx = bestSequenceOutput;
                for (int i = 0; i <sequenceDNA.length ; i++) {
                    sequenceOutput += sequenceDNA[i];
                }
            }

        }

        System.out.println(String.format("Best DNA sample %d with sum: %d. ",bestSequenceOutputMAx,bestSequenceSum));
        System.out.println((sequenceOutput.trim()));
    }
}

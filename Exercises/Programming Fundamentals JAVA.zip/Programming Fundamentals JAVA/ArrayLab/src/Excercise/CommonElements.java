package Excercise;

import java.util.Scanner;

public class CommonElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] arr = scanner.nextLine().split(" ");
        String[] secondArr = scanner.nextLine().split(" ");

        for (int i = 0; i <arr.length ; i++) {
            for (int j = 0; j <secondArr.length; j++) {
                if((arr[i]).equals(secondArr[j])){
                    System.out.print(arr[i]+ " ");
                }

            }
        }
    }
}

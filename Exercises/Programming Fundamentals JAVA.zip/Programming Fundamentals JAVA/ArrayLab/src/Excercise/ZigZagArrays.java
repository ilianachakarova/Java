package Excercise;

import java.util.Scanner;

public class ZigZagArrays {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        String [] numbers = new String[2*n];
        int index = 0;
        for (int i = 0; i <n ; i++) {
            String [] input = scanner.nextLine().split(" ");

            if(i %2 == 0){
                numbers[index++] =input[0];
                numbers[index++]=input[1];
            }
        }
    }
}

import java.util.Scanner;

public class AreaRect {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a = Double.parseDouble(scanner.nextLine());
        double b = Double.parseDouble(scanner.nextLine());
        int area = (int) calculateArea(a,b);
        System.out.println(area);
    }
    public static double calculateArea(double a, double b){
        return a*b;
    }
}

import java.util.Scanner;

public class MultiplyEvenByOdds {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Math.abs(Integer.parseInt(scanner.nextLine()));
        System.out.println(getEvenByOddMultiplication(number));
    }

    static int getEvenByOddMultiplication(int number){
        int result =1;
        int sumEven = 0;
        int sumOdd = 0;
        while(number>0){
            int digit = number%10;
            if(digit%2==0){
                sumEven += digit;
            }else {
                sumOdd += digit;
            }
            number /= 10;
        }
        result = sumEven*sumOdd;
        return result;
    }
}

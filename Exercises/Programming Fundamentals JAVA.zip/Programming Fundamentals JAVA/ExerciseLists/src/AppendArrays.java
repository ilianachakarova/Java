import java.util.Scanner;

public class AppendArrays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input =scanner.nextLine().replaceAll("\\s+", "");

        String [] lists = input.split("\\|");

        for (int i = lists.length -1; i >=0; i--) {
            String part = lists[i];
            for (int j =0; j <part.length() ; j++) {
                System.out.printf("%s ",part.charAt(j));
            }
        }




    }
}

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class CardsGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> firstPlayerCards = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        List<Integer> secondPlayerCards = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        int totalFirst = 0;
        int totalSecond =0;
        while(true){
            if(firstPlayerCards.size()==0||secondPlayerCards.size()==0){
                break;
            }else {
                if (firstPlayerCards.get(0).equals(secondPlayerCards.get(0))){
                    firstPlayerCards.remove(0);
                    secondPlayerCards.remove(0);
                }else if(firstPlayerCards.get(0)>secondPlayerCards.get(0)){
                    firstPlayerCards.add(firstPlayerCards.get(0));
                    firstPlayerCards.add(secondPlayerCards.get(0));
                    firstPlayerCards.remove(0);
                    secondPlayerCards.remove(0);
                }else {
                    secondPlayerCards.add(secondPlayerCards.get(0));
                    secondPlayerCards.add(firstPlayerCards.get(0));
                    secondPlayerCards.remove(0);
                    firstPlayerCards.remove(0);
                }


            }
            }
        if(firstPlayerCards.size()>secondPlayerCards.size()){
            totalFirst =
                    firstPlayerCards.stream().mapToInt(Integer::intValue).sum();
            System.out.println("First player wins! Sum: "+totalFirst);

        }else if(secondPlayerCards.size()>firstPlayerCards.size()){
            totalSecond =
                    secondPlayerCards.stream().mapToInt(Integer::intValue).sum();
            System.out.println("Second player wins! Sum: "+totalSecond);
        }

        }
    }


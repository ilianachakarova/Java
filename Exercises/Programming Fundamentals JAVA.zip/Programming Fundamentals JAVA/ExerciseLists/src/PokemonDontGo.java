import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class PokemonDontGo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> elements = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        int sumRemovedElements = 0;

        while (elements.size() > 0) {
            int index = Integer.parseInt(scanner.nextLine());
            if (index < 0) {
                int indexElement = elements.get(0);
                elements.remove(0);
                if (elements.size() == 0) {
                    break;
                }
                elements.add(0, elements.get(elements.size() - 1));
                elements = manipulateElementValue(elements, indexElement);

                sumRemovedElements += indexElement;
            } else if (index >= elements.size()) {
                int indexElement = elements.get(elements.size() - 1);
                elements.remove(elements.size() - 1);
                if (elements.size() == 0) {
                    break;
                }
                elements.add(elements.get(0));
                elements = manipulateElementValue(elements, indexElement);

                sumRemovedElements += indexElement;
            } else {

                int indexElement = elements.get(index);
                sumRemovedElements += indexElement;
                elements.remove(index);
                if (elements.size() == 0) {
                    break;
                }


                elements = manipulateElementValue(elements, indexElement);

                if (elements.size() == 0) {
                    break;
                }
            }

        }

        System.out.println(sumRemovedElements);
    }

    private static List manipulateElementValue(List<Integer> elements, int indexElement) {
        for (int i = 0; i < elements.size(); i++) {
            if (elements.get(i) > indexElement) {
                elements.set(i, elements.get(i) - indexElement);
            }else if (elements.get(i) <= indexElement) {
                elements.set(i, indexElement + elements.get(i));
            }
        }
        return elements;
    }

}

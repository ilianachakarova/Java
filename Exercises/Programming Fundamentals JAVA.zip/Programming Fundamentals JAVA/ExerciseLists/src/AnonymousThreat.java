import java.util.*;
import java.util.stream.Collectors;

public class AnonymousThreat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String>names = Arrays.stream(scanner.nextLine().split(" "))
                .collect(Collectors.toList());

        String input = " ";

        while (!"3:1".equals(input=scanner.nextLine())){
            String [] data = input.split("\\s+");

            String command = data[0];

            switch (command){
                case "merge":
                    int startIndex = Integer.parseInt(data[1]);
                    int endIndex = Integer.parseInt(data[2]);
                    startIndex = validateIndex(startIndex,names.size());
                    endIndex = validateIndex(endIndex,names.size());

                    String concatElements = names.subList(startIndex,endIndex)
                    .stream().filter(e ->!e.equals("")).collect(Collectors.joining(""));

                    names.subList(startIndex,endIndex).clear();

                    names.add(startIndex,concatElements);
                    break;

                case"divide":
                    int index = Integer.parseInt(data[1]);
                    int partitions = Integer.parseInt(data[2]);

                    List<String> result = dividedEqually(names.get(index),partitions);

                    names.remove(index);
                    names.addAll(index,result);
                    break;
            }
        }

        System.out.println(String.join(" "));
    }

    private static List<String> dividedEqually(String element, int partitions) {
        int part = element.length()/partitions;
        ArrayList<String> result = new ArrayList<>();

        while(element.length()>=part){
            result.add(element.substring(0,part));
            element = element.substring(part);
        }

        if(result.size() ==partitions){
            return result;
        }else {
            String concatLastTwoElements = result.get(result.size()-2).concat(result.get(result.size()-2));

            result.subList(result.size()-2,result.size()).clear();
            result.add(concatLastTwoElements);
            return result;
        }
    }

    private static int validateIndex(int index, int length){
        if(index<0){
            index = 0;
        }
        if(index>length-1){
            index = length-1;
        }
        return index;
    }
}

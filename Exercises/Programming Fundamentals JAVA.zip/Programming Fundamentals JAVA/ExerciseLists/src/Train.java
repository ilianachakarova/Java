import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Train {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        List<Integer> wagonList = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        int maxCapacity = Integer.parseInt(scanner.nextLine());

        while (true){
            String  input = scanner.nextLine();

            if(input.equals("end")){
                break;
            }

            String [] command = input.split(" ");

            if(command[0].equals("Add")){
                addWagon(wagonList,command[1]);
            }else {
                addPassengers(wagonList,command[0],maxCapacity);
            }

        }
        System.out.println(wagonList.toString().replaceAll("[\\[\\],]",""));
    }

    private static List addPassengers(List<Integer> wagonList, String command, int maxCapacity) {
        for (int i = 0; i <wagonList.size() ; i++) {
           if(wagonList.get(i)+Integer.parseInt(command)<=maxCapacity){
               wagonList.set(i,wagonList.get(i)+Integer.parseInt(command));
               break;
           }
        }
        return wagonList;

    }

    private static List addWagon(List<Integer> wagonList, String command) {
        wagonList.add(Integer.parseInt(command));
        return wagonList;
    }
}

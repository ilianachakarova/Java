import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HouseParty {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
         int n = Integer.parseInt(scanner.nextLine());

        List<String> listOfGuest = new ArrayList<>();
        for (int i = 0; i <n ; i++) {
            String input = scanner.nextLine();
            String[] command = input.split(" ");

            if(listOfGuest.contains(command[0])){
                if(command[2].equals("going!")){
                    System.out.println(command[0]+ " is already in the list!");
                    continue;
                }else {
                    listOfGuest.remove(command[0]);
                    continue;
                }
            }

            if(command[2].equals("going!")){
                listOfGuest.add(command[0]);
            }else{
                System.out.println(command[0]+ " is not in the list!");
            }

        }
        String arr [] =listOfGuest.toArray(new String[listOfGuest.size()]);
        for (int i = 0; i <arr.length ; i++) {
            System.out.println(arr[i]);
        }
    }
}

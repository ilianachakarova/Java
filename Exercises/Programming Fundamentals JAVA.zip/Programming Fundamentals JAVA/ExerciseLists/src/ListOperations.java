import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ListOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> numbers = Arrays.stream(scanner.nextLine().split("\\s+"))
                .map(Integer::parseInt)
                .collect(Collectors.toList());



        while (true) {
            String line = scanner.nextLine();
            if (line.equals("End")) {
                break;
            }

            String[] command = line.split(" ");

            switch (command[0]) {
                case "Add":
                    numbers.add(Integer.parseInt(command[1]));
                    break;
                case "Insert":
                    if (Integer.parseInt(command[2]) >= 0 && Integer.parseInt(command[2]) < numbers.size()) {
                        int indexNum = Integer.parseInt(command[2]);
                        numbers.add(indexNum,Integer.parseInt(command[1]));
                    } else {
                        System.out.println("Invalid index");
                    }
                    break;
                case "Remove":
                    if (Integer.parseInt(command[1]) >= 0 && Integer.parseInt(command[1]) < numbers.size()) {
                        numbers.remove(Integer.parseInt(command[1]));
                    } else {
                        System.out.println("Invalid index");

                    }
                    break;
                case "Shift":
                    if ((command[1]).equals("left")) {
                        int counter = 0;
                        for (int i = 0; counter<Integer.parseInt(command[2]); i++) {
                            counter++;
                            numbers.add(numbers.size(), numbers.get(i));
                            numbers.remove(0);
                            i--;

                        }
                    } else if (command[1].equals("right")) {
                        int counter =0;
                        for (int i = 0;counter < Integer.parseInt(command[2]); i++) {
                            counter++;
                            numbers.add(0, numbers.get(numbers.size()-1));
                            numbers.remove(numbers.size() - 1);
                            i--;
                        }
                    }
                    break;

            }
        }
        System.out.println(numbers.toString().replaceAll("[\\[\\],]", ""));
    }
}

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ChangeList {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> elements = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

       while (true){
            String line = scanner.nextLine();

            if(line.equals("end")){
                break;
            }

            String[] command = line.split("\\s+");

            switch (command[0]){
                case"Delete":
                    for (int i = 0; i <elements.size() ; i++) {
                        if(elements.get(i)== Integer.parseInt(command[1])){
                            elements.remove(i);
                            i = -1;
                        }
                    }
                    break;
                case"Insert":
                    int position = Integer.parseInt(command[2]);
                    if(position>=0&&position<elements.size()) {
                        elements.add(Integer.parseInt(command[2]), Integer.parseInt(command[1]));
                        break;
                    }
            }

       }

        System.out.println(elements.toString().replaceAll("[\\[\\],]",""));
    }
}
